### BitRPC
Allows for sending of all standard Bitcoin commands via RPC rather than as command line args.

### Looking for Wallet Tools?
BitRPC.py is able to do the exact same thing as `walletchangepass.py` and `walletunlock.py`. Their respective commands in BitRPC.py are:

	bitrpc.py walletpassphrasechange
	bitrpc.py walletpassphrase