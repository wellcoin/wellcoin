Sample configuration files for:

SystemD: wellcoind.service
Upstart: wellcoind.conf
OpenRC:  wellcoind.openrc
         wellcoind.openrcconf
CentOS:  wellcoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
