
Debian
====================
This directory contains files used to package wellcoind/wellcoin-qt
for Debian-based Linux systems. If you compile wellcoind/wellcoin-qt yourself, there are some useful files here.

## wellcoin: URI support ##


wellcoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install wellcoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your wellcoinqt binary to `/usr/bin`
and the `../../share/pixmaps/wellcoin128.png` to `/usr/share/pixmaps`

wellcoin-qt.protocol (KDE)

